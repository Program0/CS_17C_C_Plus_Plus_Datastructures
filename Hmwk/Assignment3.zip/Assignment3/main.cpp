#include <iostream>

using namespace std;

void bubbleSort(int *array, int size);

int main()
{
    cout << "Hello World!" << endl;
    return 0;
}

void bubbleSort(int *array, int size){
    for(int i = 0; i<size-1;i++){
        for(int j=i+1;j<size-1;j++){

        }
    }
}
