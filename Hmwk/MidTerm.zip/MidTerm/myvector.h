/*
 * Author: Marlo Zeroth
 * File: myvector.h
 * Template class used to implement a vector.
 */

#ifndef MYVECTOR_H
#define MYVECTOR_H

#include <iostream>
#include <new>
#include <cstdlib>

#include "empty.h"

template<class T>
class MyVector {
public:

	/*Constructors and Destructor*/

	// Default constructor
	MyVector();

	// Main constructor
	MyVector(int size);

	// Copy constructor
	MyVector(const MyVector &);

	// Destructor
	~MyVector();

	/*Accessor and Mutator functions*/

	// Overloaded = operator
	MyVector<T> & operator =(const MyVector<T> & input);

	// Overloaded [] operator
	T& operator[](const int &);

	// Overloaded [] operator for const
	const T& operator[](const int &sub) const;

	// Returns an element at specified parameter
	T getElementAt(const int &position);

	// Adds one element to the top of the vector
	void push(const T &data);

	// Adds an array of type T to the vector
	void push(const T *data, int size);

	// Returns the top value of the vector and decreases the vector size
	// by 1.
	T pull() throw (Empty);

	// Sorts the vector
	void sort();

	// Empties the vector and returns to default size
	void clear() throw (Empty);

	// Returns the total elements in the vector
	int length() const {
		return top;
	}

	// Returns the capacity of the vector
	int capacity() const {
		return arraySize;
	}

	// Returns true if vector is empty
	bool isEmpty() const;

private:
	// Class constants
	static const int DEFAULTSIZE;
	static const int MAXIMUMSIZE;

	/* Utility functions */
	void memError() const; // Returns EXIT_FAILURE for failed memory allocation
	void subError() const; // Returns EXIT_FAILURE for subscript out of range

	// Help with sorting the internal array.
	void mergeSort(T *array, T *tempArray, int first, int last);
	void mergeArrays(T *array, T *tempArray, int first, int mid, int last);

	// Member variables
	T *aptr;         // To point to the allocated array
	int arraySize;   // Number of elements in the array
	int top;         // Position of last element in vector
};

// Defining constants
template<class T>
const int MyVector<T>::DEFAULTSIZE = 10;
template<class T>
const int MyVector<T>::MAXIMUMSIZE = 10000000;

/* Constructors and Destructor */

// Default constructor
template<class T>
MyVector<T>::MyVector() {

	arraySize = DEFAULTSIZE;
	// Allocate memory for the array.
	try {
		aptr = new T[arraySize];
	} catch (const std::bad_alloc&) {
		memError();
	}

	// Initialize the array.
	for (int count = 0; count < arraySize; count++)
		*(aptr + count) = 0;

	// The first element is the last element
	top = 0;
}

// Main constructor
template<class T>
MyVector<T>::MyVector(int s) {

	// Check to see if the passed parameter is greater than
	// the default size of the vector.
	(s > DEFAULTSIZE) ? arraySize = s : arraySize = DEFAULTSIZE;
	// Allocate memory for the array.
	try {
		aptr = new T[arraySize];
	} catch (const std::bad_alloc&) {
		memError();
	}

	// Initialize the array.
	for (int count = 0; count < arraySize; count++)
		*(aptr + count) = 0;

	// The first element is the last element
	top = 0;
}

// Copy constructor
template<class T>
MyVector<T>::MyVector(const MyVector &obj) {

	// Copy the array size.
	arraySize = obj.arraySize;
	// Allocate memory for the array.
	try {
		// Attempt memory allocation
		aptr = new T[arraySize];

	} catch (const std::bad_alloc&) {
		memError();
	}

	// Copy the elements of obj's array.
	for (int count = 0; count < arraySize; count++)
		*(aptr + count) = *(obj.aptr + count);

	// Set location of top/last element
	top = obj.top;
}

// Destructor
template<class T>
MyVector<T>::~MyVector() {
	if (arraySize > 0) {
		delete[] aptr;
	}
}

//*******************************************************
// Overloaded = operator. The argument is an object of 	*
// type MyVector<T>. This function returns a reference  *
// an object type MyVector<T>. It deep copies all 		*
// elements from the passed parameter into the calling  *
// object.												*
//*******************************************************
template<class T>
MyVector<T>& MyVector<T>::operator =(const MyVector<T> & obj) {
	// Test to make sure the passed object is not the calling
	// object.
	if (this != &obj) {

		// Clear out the existing vector
		delete[] aptr;
		// Set the new top and arraySize
		arraySize = obj.arraySize;
		top = obj.top;

		// Allocate memory for the new vector
		try {
			aptr = new T[arraySize];
		} catch (const std::bad_alloc&) {
			memError();
		}
		// Deep copy all the new elements
		for (int i = 0; i < arraySize; i++) {
			*(aptr + i) = *(obj.aptr + i);
		}
	}
	// Just return a reference to this
	return *this;
}

//*******************************************************
// Overloaded [] operator. The argument is a subscript. *
// This function returns a reference to the element     *
// in the array indexed by the subscript.               *
//*******************************************************

template<class T>
T& MyVector<T>::operator[](const int &sub) {
	if (sub < 0 || sub >= arraySize)
		subError();

	return aptr[sub];
}

template<class T>
const T& MyVector<T>::operator[](const int &sub) const {
	if (sub < 0 || sub >= arraySize)
		subError();

	return aptr[sub];
}

//*******************************************************
// getElementAt function. The argument is a subscript.  *
// This function returns the value stored at the 	    *
// subscript in the array.                              *
//*******************************************************

template<class T>
T MyVector<T>::getElementAt(const int &sub) {

	if (sub < 0 || sub >= arraySize)
		subError();

	return aptr[sub];
}

//*******************************************************
// push function. Mutator to add one element to the top *
// of the vector array and increase the array size by 1 *
// and double the vector size.                          *
//*******************************************************
template<class T>
void MyVector<T>::push(const T & data) {

	// Test if there is room in the array to add one more element
	// If there is, just add the new data element.
	if (top < arraySize - 2) {

		// Test to make sure we are not pointing at null
		// Note program ends if we are out of bounds
		if (aptr == 0) {
			memError();
		}
		// Now add the new element and increment the
		// position of the last element.
		aptr[top++] = data;
	}
	// If there is not, double the array size and copy to a new array
	else {
		// Increase the array size
		arraySize *= 2;

		T *tempPtr;	// to hold temporary array

		// Allocate memory. Will end program if failed.
		try {
			tempPtr = new T[arraySize];
		} catch (const std::bad_alloc&) {
			memError();
		}

		// Copy the existing array elements into the new one
		for (int count = 0; count < top; count++) {
			tempPtr[count] = aptr[count];
		}
		// Now add the new element at the end,
		// and increment the position of the last element.
		tempPtr[top++] = data;

		// Deallocate the old array.
		delete[] aptr;

		// Set pointer to the new array.
		aptr = tempPtr;
	}
}

//*******************************************************
// push function. Mutator to add an array elements to 	*
// vector increase the internal array size by by passed *
// parameter size.				                        *
//*******************************************************
template<class T>
void MyVector<T>::push(const T *data, int size) {

	// Check to make sure there is room in the current
	// vector.
	if ((arraySize - top) - size > 1) {
		// If there is room, copy the passed array
		// starting at the last next available index
		// of the vector
		for (int i = 0; i < size; i++) {
			aptr[top++] = data[i];
		}
	}
	// If there is no room, create a new array and copy
	// the passed array into the new one.
	else {
		// Allocate memory for twice the size of the
		// passed array size and internal array size.
		arraySize = (size + arraySize) * 2;
		T *temp;
		try {
			temp = new T[arraySize];
		} catch (const std::bad_alloc&) {
			memError();
		}
		// Copy the original first
		for (int i = 0; i < top; i++) {
			temp[i] = aptr[i];
		}
		// Now add the new array
		for (int i = 0; i < size; i++) {
			temp[top++] = data[i];
		}

		// Deallocate current array and set to new temp array
		delete[] aptr;
		aptr = temp;
	}
}

//*******************************************************
// pull function. Accessor to remove and return the top *
// element of the vector. Decreases the array size by 1 *
// and if the last element was removed returns 0 (null) *
//*******************************************************

template<class T>
T MyVector<T>::pull() throw (Empty) {

	if (top > 0) {
		// Get the element at the end of the array,
		// decrease the position of the last element by 1.
		return aptr[--top];
	}
	// If the last element returned was aptr[0], then
	// there is nothing left in the vector. We just throw an exception.
	throw Empty();
}

// Sorts the vector in ascending order
template<class T>
void MyVector<T>::sort() {

	T *tempArray;
	// Allocate memory for the array.
	try {
		// Allocate memory for the temporary array
		tempArray = new T[top];
		// Set the first and last positions
		int first = 0;
		int last = top - 1;

		// Now merge sort the arrays
		mergeSort(aptr, tempArray, first, last);
		// Now deallocate the temporary array
		delete [] tempArray;

	} catch (const std::bad_alloc&) {
		memError();
	}

}

// Empties the vector and returns to default size
template<class T>
void MyVector<T>::clear() throw (Empty) {
	if (top > 0) {
		delete[] aptr;
		arraySize = DEFAULTSIZE;
		// Allocate memory for the array.
		try {
			aptr = new T[arraySize];
		} catch (const std::bad_alloc&) {
			memError();
		}

		// Initialize the array.
		for (int count = 0; count < arraySize; count++)
			*(aptr + count) = 0;

		// The first element is the last element
		top = 0;
	} else {
		throw Empty();
	}
}

// isEmpty function. Returns true if the vector is empty.
template<class T>
bool MyVector<T>::isEmpty() const {
	if (top <= 0) {
		return true;
	}
	return false;
}

/* Utility Functions */

//***************************************************
// mergeSort function. Sorts the internal array by  *
// comparing individual elements. Requires that the *
// the class type T implement the < operator for 	*
// the comparison. 									*
//***************************************************
template<class T>
void MyVector<T>::mergeSort(T *array, T *tempArray, int first, int last) {
	// Base case
	if (first < last) {
		int mid = first + (last - first) / 2;
		// Divide and conquer. Split into left and right subarrays
		// recursively
		mergeSort(array, tempArray, first, mid);
		mergeSort(array, tempArray, mid + 1, last);
		// Combine both subarrays back into one array
		mergeArrays(array, tempArray, first, mid, last);
	}
}

//***************************************************************
// mergeArrays function. Merges the sub arrays back into one.	*
//***************************************************************
template<class T>
void MyVector<T>::mergeArrays(T *array, T *tempArray, int first, int mid,
		int last) {
	// To keep track of which indexes have been merged into the tempArray
	int beginHalf1 = first;		// subarray1 starting index
	int beginHalf2 = mid + 1;		// subarray2 starting index

	// Need to copy array into tempArray to actually sort it. Important!!
	// Book's algorithm did not work for me.
	for (int i = first; i <= last; i++) {
		tempArray[i] = array[i];
	}
	// To keep track of the current element added to tempArray
	int index = first;
	// Need to keep within range of both sub arrays
	while ((beginHalf1 <= mid) && (beginHalf2 <= last)) {
		// Only copy if 1st half element is less than or equal to element in
		// 2nd half
		if (tempArray[beginHalf1] < tempArray[beginHalf2]) {
			array[index] = tempArray[beginHalf1];
			// go the next element in subarray1 to sort
			beginHalf1++;
		} else {
			array[index] = tempArray[beginHalf2];
			// go the next element in subarray 2 to sort
			beginHalf2++;

		}
		// Go to the next elements in both subarrays to be sorted
		index++;
	}

	// Now we need to copy any of the remaining elements in the first
	// subarray into array[]
	while (beginHalf1 <= mid) {
		array[index] = tempArray[beginHalf1];
		index++;
		beginHalf1++;
	}
}

//*******************************************************
// memError function. Displays an error message and     *
// terminates the program when memory allocation fails. *
//*******************************************************
template<class T>
void MyVector<T>::memError() const {
	std::cout << "ERROR:Cannot allocate memory.\n";
	exit(EXIT_FAILURE);
}

//***********************************************************
// subError function. Displays an error message and         *
// terminates the program when a subscript is out of range. *
//***********************************************************

template<class T>
void MyVector<T>::subError() const {
	std::cout << "ERROR: Subscript out of range.\n";
	exit(EXIT_FAILURE);
}

#endif
