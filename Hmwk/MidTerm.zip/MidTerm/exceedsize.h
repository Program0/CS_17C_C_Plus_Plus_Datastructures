/*
 * ExceedSizeException.h
 *
 *  Created on: Nov 3, 2015
 *      Author: super0
 */

#ifndef EXCEEDSIZE_H_
#define EXCEEDSIZE_H_

class ExceedSize{

};

#endif /* EXCEEDSIZE_H_ */
