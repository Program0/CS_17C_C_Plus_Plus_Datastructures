/* 
 * File:   statclass.h
 * Author: super0
 *
 * Created on November 9, 2015, 3:11 AM
 */

#ifndef STATCLASS_H
#define	STATCLASS_H

#include <cstdlib>
#include <map>
#include <iterator>
#include <string>
#include <sstream>

#include "myvector.h"
#include "mylist.h"
#include "empty.h"


class StatClass {
public:    
    // Main constructors
    StatClass(MyVector<int> x);
    StatClass(MyList<int> &x);
    
    /* Accessors */
    int getMax()const{return max;}
    int getMin()const{return min;}
    float getAverage()const{return average;}
    int getFrequency()const{return frequency;}
    int getNumberModes()const {return numberModes;}
    std::string getModes()const{return modes;}  
    
private:
    int frequency;
    int numberModes;
    int min;
    int max;
    float average;
    std::string modes;

};


#endif	/* STATCLASS_H */

