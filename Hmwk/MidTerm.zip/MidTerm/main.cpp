/*
 *  Runs the main loop for the midterm problem set. Includes
 *  functions for user input.
 *  File: main.cpp
 *  Created on: Nov 4, 2015
 *      Author: Marlo Zeroth
 */

#include <iostream>
#include <cstdlib>
#include <sstream>
#include <string>
#include <ctime>

// User libraries
#include "midterm.h"
#include "myvector.h"

int getOption();
void exitCase(const int &exitNumber);

int main() {

	using namespace std;

	int numberOfProblems = 9;
	int problemSelected;

	//Initialize the random number generator
	srand(static_cast<unsigned int>(time(0)));

	MyVector<int> x;
/*
	for(int i =0; i<15;i++){
		x.push(i);
	}
	cout<<"Printing elements: "<<endl;
	for(int i =0; i<15;i++){
		cout<<x[i]<<endl;
	}

	MyVector<int>y;
	y=x;
	cout<<"Printing elements: "<<endl;
		for(int i =0; i<15;i++){
			cout<<y[i]<<endl;
		}
*/

	MidTerm midterm;
	do {

		problemSelected = getOption();
		cout << "You selected " << problemSelected << endl;
		switch (problemSelected) {
		case 1:
			midterm.problem1();
			break;
		case 2:
			midterm.problem2();
			break;
		case 3:
			midterm.problem3();
			break;
		case 4:
			midterm.problem4();
			break;
		case 5:
			midterm.problem5();
			break;
		case 6:
			midterm.problem6();
			break;
		case 7:
			midterm.problem7();
			break;
		case 8:
			midterm.problem8();
			break;
		case 9:
			midterm.problem9();
			break;
		default:
			exitCase(problemSelected);

		}

	} while (problemSelected > 0 && problemSelected <= numberOfProblems);

	return 0;
}

int getOption() {

	using namespace std;
	string s; // for user input
	int option = 0; // to check the option
	bool valid = false; // to make user input is valid
	// Prompt user for input
	cout << "Enter your option: ";
	cin >> option;

	//Keep asking until user enters valid input
	do {
		unsigned int index = 0;
		bool isInt = true;
		char test;
		// Check to make sure the string input is valid
		while (index < s.length() && isInt && s != "") {
			test = s[index];
			if (!isdigit(test))
				isInt = false;
			index++;
		}
		// Set the option to user input
		if (isInt) {
			stringstream stream(s);
			stream >> option;
			valid = true;
		}
		// If it is not valid ask for valid option
		if (!valid)
			cout << "Please enter a valid option." << endl;

	} while (!valid);

	return option;

}

void exitCase(const int &exitNumber) {
	std::cout << "You entered: " << exitNumber << ". Exiting program" << std::endl;
}
