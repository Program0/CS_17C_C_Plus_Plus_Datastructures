

#include "stuff.h"

std::string Stuff::toString() {
    std::string contents;
    contents = quantity + " " + stuffName + " ";
    return contents;
}

bool Stuff::operator<(const Stuff &stuff) {
    // We want in ascending order
    return quantity - stuff.quantity;
}

bool Stuff::operator==(const Stuff &stuff) {
    if (quantity == stuff.quantity && stuffName == stuff.stuffName)
        return true;
    return false;
}