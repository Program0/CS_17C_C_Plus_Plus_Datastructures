/*
 * MyList.h
 *
 *  Created on: Nov 4, 2015
 *      Author: super0
 */

#ifndef MYLIST_H_
#define MYLIST_H_

#include <new>


/*Forward declarations*/
template<typename T> class Iterator;
template<typename T> class MyList;

// Internal Node struct to hold data and point to other nodes
template<class T>
class Node {
public:
	// For allowing access by MyList class.
	//template<typename T>
	friend class MyList<T> ;

	// For allowing access while iterating through the list
	//template<typename T>
	friend class Iterator<T> ;
private:
	T data;
	Node *next;
	Node *previous;

};

template<typename T>
class Iterator {
public:

	// Default constructor. Does not point to anything on the list.
	Iterator();

	// Returns a reference to the node data
	T& get() const;

	// Moves the iterator to the next node
	void next();

	// Moves the iterator to the previous node
	void previous();

	// Compares two iterators
	bool equals(Iterator<T> b) const;

	//template<typename T>
	friend class MyList<T> ;

private:
	Node<T> *position;
	Node<T> *last;
};

/*Iterator definitions*/

// Default constructor
template<class T>
Iterator<T>::Iterator() {
	position = NULL;
	last = NULL;
}

// Returns a reference to the node data
template<class T>
T& Iterator<T>::get() const {
	return position->data;
}

// Moves the iterator to the next node
template<class T>
void Iterator<T>::next() {
	// Go to the next node
	position = position->next;
}

// Moves the iterator to the previous node
template<class T>
void Iterator<T>::previous() {
	// If it is not null go to the previous node
	if (position) {
		position = position->previous;
	} else {
		position = last;
	}
}

// Compares two iterators
template<class T>
bool Iterator<T>::equals(Iterator<T> b) const {
	// Return whether we are at the same position
	return position == b.position;
}

template<class T>
class MyList {

public:
	// Default constructor
	MyList();

	// Main constructor
	MyList(const T &entry);

	// Copy constructor
	MyList(const MyList<T> &obj);

	// Destructor
	virtual ~MyList();

	// Overloaded Operators

	// Overloaded [] operator
	T & operator[](const int & sub) throw (Empty);

	// Overloaded [] operator for const correctness
	const T& operator[](const int & sub) const throw (Empty);

	// Oveloaded = operator
	MyList<T>& operator=(const MyList<T> &obj);

	/* Mutators and Accessors */

	// Adds an entry to the front of the list
	void prepend(const T& entry);

	// Adds an entry to the back of the list
	void append(const T& entry);

	// Inserts an element before the passed parameter
	void insertBefore(const T& position, const T& entry);

	// Inserts an element after the passed parameter
	void insertAfter(const T& position, const T& entry);

	// Returns the first element in the list
	T& first() throw (Empty);

	// Returns the last element in the list
	T& last() throw (Empty);

	// Returns a pointer to the beginning of the list.
	Iterator<T> begin();
        
        Iterator<T> begin() const;

	// Returns a pointer to the end of the list.
	Iterator<T> end();
        Iterator<T> end() const;

	// Sorts the list in ascending order
	void sort();

	// Returns the size of the list
	int length() const {
		return size;
	}

	// Removes all items for the list
	void clear();

private:

	/*Utility functions*/
	void memError() const; // Handles memory allocation errors
	void subError() const; // Handles subscripts out of range

	// Sorts the vector in ascending order
	void mergeSort(T *array, T *tempArray, int first, int last);
	void mergeArrays(T *array, T *tempArray, int first, int mid, int last);

	// Returns the position of an entry in the list
	Node<T> position(const T& entry) const;

	/* MyList Member variables */
	Node<T> *head; // Reference to top/head node
	Node<T> *tail; // Reference to last/tail node
	int size;

};

/* Constructors */

// Default constructor
template<class T>
MyList<T>::MyList() {
	tail = NULL;
	head = NULL;
	size = 0;
}

//****************************************************************
// Main constructor. Adds an entry and increments the size by 1. *
//****************************************************************
template<class T>
MyList<T>::MyList(const T &entry) {

	// Create new node with entry parameter
	Node<T> *link;
	// Attempt to allocate memory
	try {
		link = new Node<T>;

	} catch (const std::bad_alloc&) {
		memError();
	}
	// Set its data member and pointers
	link->data = entry;
	link->next = NULL;
	link->previous = NULL;

	// Now point the head and tail to this new link in the list
	head = tail = link;
	size++;

}

// Copy constructor. This is order O(N).
template<class T>
MyList<T>::MyList(const MyList<T> &obj) {
    std::cout<<"copy constructor"<<std::endl;
	
	// Set the head and tail pointers to null.
	tail = head = NULL;

	// Set the size of the list
	size = 0;

	// Now set the cursor to the object's head and
	// traverse the links in obj if there are any.
        Node<T> *cursor; // For navigating through the obj list
	for(cursor = obj.head;cursor!=0;cursor=cursor->next){
            append(cursor->data);
        }	
}

// Destructor
template<class T>
MyList<T>::~MyList() {	

	// Traverse the list deleting each link
	while (head) {
            // Set the cursor to the current head
            Node<T> *cursor = head;
            // Set the head pointer to the next link
            head = head->next;
            // Deallocate the current link
            delete cursor;
	}
        tail = NULL;
}

// Overloaded operators

// Overload [] operator declaration. The returned object can be
// modified. Throws an Empty exception if the list is empty.
template<class T>
T & MyList<T>::operator[](const int & sub) throw (Empty) {

	// If the subscript is out of range give message
	// and exit
	if (sub < 0 || sub >= size)
		subError();

	// If the list is empty give a message and throw an exception
	if (size == 0 || head == NULL) {
		std::cout << "List is empty" << std::endl;
		throw Empty();
	}

	// Otherwise we traverse the list until we find the
	// desired position.
	int count = 0;
	Node<T> *cursor = head;

	// Keep going until we reach the desired element
	while (cursor && count < sub) {
		// Go to the next one
		cursor = cursor->next;
		count++;
	}

	// We found it!
	return cursor->data;
}

// Overload [] const operator declaration. Guarantees that
// the returned object will not be modified.
// Throws an Empty exception if the list is empty
template<class T>
const T& MyList<T>::operator[](const int & sub) const throw (Empty) {

	// If the subscript is out of range give message
	// and exit
	if (sub < 0 || sub >= size)
		subError();

	// If the list is empty give a message and throw an exception
	if (size == 0 || head == NULL) {
		std::cout << "Error:The list is empty" << std::endl;
		throw Empty();
	}

	// Otherwise we traverse the list until we find the
	// desired position.
	int count = 0;
	Node<T> *cursor = head;

	// Keep going until we reach the desired subscript
	while (cursor && count < sub) {
		// Go to the next one
		cursor = cursor->next;
		count++;
	}

	// We found it!
	return cursor->data;
}

// Overload = operator declaration
template<class T>
MyList<T>& MyList<T>::operator=(const MyList<T> &obj) {

    std::cout<<"= operator "<<std::endl;
	// Test to make sure the passed object is not the same
	// as calling object e.g. input = input
	if (this != &obj) {
            clear();
            // Set the size of the list
            size = 0;           

            // Now set the cursor to the object's head and
            // traverse the links in obj if there are any.
            Node<T> *cursor; // For navigating through the obj list
            for(cursor = obj.head;cursor!=0;cursor=cursor->next){
                append(cursor->data);
            }            
	}
	// Just return a reference
	return *this;
}

/*Mutators and accessors*/

//****************************************************************
// prepend Function. Adds a element at the beginning of the list *
//****************************************************************
template<class T>
void MyList<T>::prepend(const T& input) {
	// Create a new node for the input.
	Node<T> *link;

	// Allocate memory
	try {
		link = new Node<T>;

	} catch (const std::bad_alloc&) {
		memError();
	}

	// Set its data element.
	link->data = input;

	// If the list is empty, add the new link and point head and tail to it
	if (!head) {
		// Set the link's next and previous to null as this is the only link
		link->next = NULL;
		link->previous = NULL;
		// Now point the head and tail to the new link
		tail = head = link;
		size++;

	} else {
		// Since it will be at the beginning, it should
		// point to the current first link in the list.
		link->next = head;
                link->previous = NULL;
		// Now set the previous pointer in the existing first link
		// to the new link.
		head->previous = link;
		// Set the new head.
		head = link;
		size++;
	}
}

//**********************************************************
// append Function. Adds a element at the end of the list. *
//**********************************************************
template<class T>
void MyList<T>::append(const T& input) {
	// Create a new node for the input.
	Node<T> *link;

	// Allocate memory
	try {
		link = new Node<T>;

	} catch (const std::bad_alloc&) {
		memError();
	}

	// Set its data element.
	link->data = input;

	// If the list is empty, add the new link and point head and tail to it
	if (!tail) {
		// Set the link's next and previous to null as this is the only link
		link->next = NULL;
		link->previous = NULL;
		// Now point the head and tail to the new link
		tail = head = link;
		size++;

	} else {
		// Since it will be at the end, it should
		// point to the current last link in the list.
		link->previous = tail;
                link->next = NULL;
		// Now set the next pointer in the existing last link
		// to the new link.
		tail->next = link;
		// Set the new tail.
		tail = link;
		size++;
	}
}

// Inserts an element before the passed parameter
template<class T>
void MyList<T>::insertBefore(const T& location, const T& entry) {

	Node<T> cursor = position(location);
	// If the location is in the list add the entry before it
	// otherwise append it to the list
	if (cursor) {
		// If the place to enter before is the head
		// prepend the entry
		if (!cursor->previous) {
			prepend(entry);
		} else {
			Node<T> link;
			// Allocate memory
			try {
				link = new Node<T>;

			} catch (const std::bad_alloc&) {
				memError();
			}
			// Set the data
			link->data = entry;
			// Set the new link in between the other two links
			link->previous = cursor->previous;
			link->next = cursor;
			// Set the previous links next pointer to be the new link
			cursor->previous->next = link;
			// Set the current link's previous pointer to be the new link
			cursor->previous = link;
		}
	} else {
		prepend(entry);
	}

}

// Inserts an element after the passed parameter
template<class T>
void MyList<T>::insertAfter(const T& location, const T& entry) {

	Node<T> cursor = position(location);
	// If the location is in the list add the entry before it
	// otherwise append it to the list
	if (cursor) {
		// If the place to enter after is the tail
		// append the entry
		if (!cursor->next) {
			append(entry);
		} else {
			Node<T> link;
			// Allocate memory
			try {
				link = new Node<T>;

			} catch (const std::bad_alloc&) {
				memError();
			}
			// Set the data
			link->data = entry;
			// Set the new link in between the other two links
			link->previous = cursor;
			link->next = cursor->next;
			// Set the previous links next pointer to be the new link
			cursor->next->previous = link;
			// Set the current link's previous pointer to be the new link
			cursor->next = link;
		}
	} else {
		append(entry);
	}
}

// Retursn the first element in the list
template<class T>
T& MyList<T>::first() throw (Empty) {
	if (head) {
		return head->data;
	} else {
		throw Empty();
	}

}

//******************************************************
// last function. Returns the last element in the list *
//******************************************************
template<class T>
T& MyList<T>::last() throw (Empty) {
	if (tail) {
		return tail->data;
	} else {
		throw Empty();
	}
}

//*******************************************************************
// begin function. Returns an iterator to the beginning of the list *
//*******************************************************************
template<class T>
Iterator<T> MyList<T>::begin() {
	// Create an iterator and set its
	// position to the head.
	Iterator<T> iterator;
	iterator.position = head;
	return iterator;
}

//*******************************************************************
// begin function. Returns an iterator to the beginning of the list *
//*******************************************************************
template<class T>
Iterator<T> MyList<T>::begin() const {
	// Create an iterator and set its
	// position to the head.
	Iterator<T> iterator;
	iterator.position = head;
	return iterator;
}

//***********************************************************
// end function. Returns an iterator to the end of the list *
//***********************************************************
template<class T>
Iterator<T> MyList<T>::end() {
	// Create an iterator and set its position to the
	// tail.
	Iterator<T> iterator;
	iterator.position = tail;
	return iterator;
}

//***********************************************************
// end function. Returns an iterator to the end of the list *
//***********************************************************
template<class T>
Iterator<T> MyList<T>::end() const {
	// Create an iterator and set its position to the
	// tail.
	Iterator<T> iterator;
	iterator.position = tail;
	return iterator;
}

// This is an inefficient sort. Better sort would be
// to sort the list elements itself rather than copying
// into an array and sorting. Temporary fix.

//***************************************************
// sort function. Sorts the list in ascending order *
//***************************************************
template<class T>
void MyList<T>::sort() {
// We only need to sort if the list has more than one element
	if (head && size > 1) {
		// For sorting the list
		T *array;
		T *tempArray;
		// Allocate memory for the arrays and sort.
		try {
			array = new T[size];
			// Allocate memory for the temporary array
			tempArray = new T[size];

			// Copy the elements into the array
			int index = 0;
			Node<T> *cursor = head;
			// Go through each node and copy
			// into the array
			while (index < size && cursor) {
				// Copy the data into the array
				array[index] = cursor->data;
				// Go to the next node
				cursor = cursor->next;
				index++;
			}

			// Set the first and last positions
			int first = 0;
			int last = size - 1;
			// Now merge sort the arrays
			mergeSort(array, tempArray, first, last);

			// Reset the counters
			index = 0;
			cursor = head;
			// Now replace the elements in the list
			while (index < size && cursor) {
				cursor->data = array[index];
				index++;
				cursor = cursor->next;
			}
			// Deallocate the arrays
			delete[] array;
			delete[] tempArray;

		} catch (const std::bad_alloc&) {
			memError();
		}

	}
}

//***************************************************************************
// clear function. Deallocates each link in the list and sets the size to 0 *
//***************************************************************************
template<class T>
void MyList<T>::clear() {
        Node<T> *cursor;
	// Clear out the data in the existing list
	while (head) {
            // Set the cursor to the current head
            cursor = head;			
            // Set the head pointer to the next link
            head = head->next;
            // Deallocate the current link
            delete cursor;
	} 
        tail = NULL;
	size = 0;
}

/*Utility Functions*/

//*******************************************************
// memError function. Displays an error message and     *
// terminates the program when memory allocation fails. *
//*******************************************************
template<class T>
void MyList<T>::memError() const {
	std::cout << "ERROR:Cannot allocate memory.\n";
	exit (EXIT_FAILURE);
}

//***********************************************************
// subError function. Displays an error message and         *
// terminates the program when a subscript is out of range. *
//***********************************************************
template<class T>
void MyList<T>::subError() const {
	std::cout << "ERROR: Subscript out of range.\n";
	exit (EXIT_FAILURE);
}

// Returns the position of an entry in the list.
// If the entry is not in the list, it returns null.
template<class T>
Node<T> MyList<T>::position(const T& entry) const {
	Node<T> *cursor;
	cursor = head;
	while (cursor->data != entry && cursor) {
		cursor->next;
	}
	return cursor;
}

// Uses merge sort to sort the list
template<class T>
void MyList<T>::mergeSort(T *array, T *tempArray, int first, int last) {
	// Base case
	if (first < last) {
		int mid = first + (last - first) / 2;
		// Divide and conquer. Split into left and right subarrays
		// recursively
		mergeSort(array, tempArray, first, mid);
		mergeSort(array, tempArray, mid + 1, last);
		// Combine both subarrays back into one array
		mergeArrays(array, tempArray, first, mid, last);
	}
}

//***************************************************************
// mergeArrays function. Merges the sub arrays back into one.	*
//***************************************************************
template<class T>
void MyList<T>::mergeArrays(T *array, T *tempArray, int first, int mid,
		int last) {
	// To keep track of which indexes have been merged into the tempArray
	int beginHalf1 = first;		// subarray1 starting index
	int beginHalf2 = mid + 1;		// subarray2 starting index

	// Need to copy array into tempArray to actually sort it. Important!!
	// Book's algorithm did not work for me.
	for (int i = first; i <= last; i++) {
		tempArray[i] = array[i];
	}
	// To keep track of the current element added to tempArray
	int index = first;
	// Need to keep within range of both sub arrays
	while ((beginHalf1 <= mid) && (beginHalf2 <= last)) {
		// Only copy if 1st half element is less than or equal to element in
		// 2nd half
		if (tempArray[beginHalf1] < tempArray[beginHalf2]) {
			array[index] = tempArray[beginHalf1];
			// go the next element in subarray1 to sort
			beginHalf1++;
		} else {
			array[index] = tempArray[beginHalf2];
			// go the next element in subarray 2 to sort
			beginHalf2++;

		}
		// Go to the next elements in both subarrays to be sorted
		index++;
	}

	// Now we need to copy any of the remaining elements in the first
	// subarray into array[]
	while (beginHalf1 <= mid) {
		array[index] = tempArray[beginHalf1];
		index++;
		beginHalf1++;
	}
}

#endif /* MYLIST_H_ */
