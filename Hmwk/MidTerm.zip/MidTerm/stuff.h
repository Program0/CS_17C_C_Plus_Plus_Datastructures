/* 
 * File:   stuff.h
 * Author: super0
 *
 * Created on November 9, 2015, 7:55 AM
 */

#ifndef STUFF_H
#define	STUFF_H

#include <cstdlib>
#include <iostream>
#include <string>

class Stuff{
private: 
    int quantity;// How much do you have of this stuff
std::string stuffName;// The name of this  stuff	
public:

Stuff() : quantity(0), stuffName("a") {};

Stuff(int thing1, std::string thing2):quantity(thing1),stuffName(thing2) {};

int getQuantity() {return quantity;}

std::string getName() {return stuffName;}

std::string toString();
		
bool operator<(const Stuff &stuff);

bool operator==(const Stuff &stuff);

};


#endif	/* STUFF_H */

