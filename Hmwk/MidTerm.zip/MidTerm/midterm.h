/*
 * This is the interface for the midterm class
 * It
 * File: MidTerm.h
 *
 *  Created on: Nov 4, 2015
 *      Author: Marlo Zeroth
 */

#ifndef MIDTERM_H_
#define MIDTERM_H_

#include <iostream> // General input-output
#include <ctime> // For random number generation
#include <cmath> // For comparing the recursive tan function
#include <cstdlib>
#include <string>
#include <sstream>

// User libraries
#include "myvector.h"
#include "mylist.h"
#include "exceedsize.h"
#include "statclass.h"
//#include "orderedlist.h"
#include "stuff.h"

class MidTerm {
public:
	void problem1();
	void problem2();
	void problem3();
	void problem4();
	void problem5();
	void problem6();
	void problem7();
	void problem8();
	void problem9();
	int getInput();

private:

	/*Utility functions*/

	// Helper functions for problem 1-3
	void fillVector(MyVector<int> &x, int numberOfEntries);
	MyVector<int> top(const MyVector<int> &x, const int &p) throw (ExceedSize);
	void printVector(const MyVector<int> &x, int perLine);
	MyVector<int> mode(MyVector<int> &x);

	// Helper functions for problem 4-6
	void fillList(MyList<int> &x, int numberOfEntries);
	MyList<int> top(const MyList<int> &x, const int &p) throw (ExceedSize);
	void printList(const MyList<int> &x, int perLine);
	MyList<int> mode(MyList<int> &x);
        
        // Problem 7
        //void printList(const super0::OrderedList<Stuff> &x, int perLine);
        
        // Problem 8
        double myTan(double x);
        
        // Problem 9
        double h(double x);
        double g(double x);

	void memError() const;

};

#endif /* MIDTERM_H_ */
