//============================================================================
// Name        : MidTerm.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include "midterm.h"

// Problem 1

void MidTerm::problem1() {

    int vectorSize; // To hold the requested size
    int p; // To hold how many to print out

    std::cout << " You chose problem 1." << std::endl;

    std::cout << std::endl;
    std::cout << "How big a vector do you want? ";
    vectorSize = getInput();
    std::cout << "You chose " << vectorSize << " as the vector size." << std::endl;
    std::cout << "How many top elements would you like? ";
    p = getInput();

    MyVector<int> topVector;
    MyVector<int> myVector;
    fillVector(myVector, vectorSize);
    printVector(myVector, 10);
    std::cout << "After sorting vector contains: " << std::endl;
    myVector.sort();
    printVector(myVector, 10);
    // Now get the top p elements.
    topVector = top(myVector, p);
    std::cout << "The top " << p << " elements are: " << std::endl;
    printVector(topVector, 10);
    std::cout << std::endl;
}

// Problem 2

void MidTerm::problem2() {
    // Declare and fill two vectors. One vector with no mode, one
    // with modes.

    std::cout << "\nYou chose problem 2.";

    std::cout << "How big a vector do you want?"
            << "\nNote this will display as a string";

    // Declare and fill the vector with random stuff up to given size
    MyVector<int> noMode;
    int size = getInput();
    // Get what the user wants to mode by
    std::cout << "What do you want to mod by? " << std::endl;
    int mod = getInput();
    // Fill the vector with numbers where there is no mode to test the
    // mode() function
    for (int i = 0; i < size; i++) {
        noMode.push(i);
    }

    // Output the unsorted array then sort and output again
    std::cout << "\nTesting mode(vector) on a vector with no modes "
            << "size: " + noMode.length() << " and has: " << std::endl;
    printVector(noMode, mod);
    MyVector<int> testMode;
    testMode = mode(noMode);
    std::cout << "\nIt has " << testMode[0] << " modes, highest frequency of " << testMode[1] << std::endl;

    MyVector<int> hasMode;

    for (int i = 0; i < size; i++) {
        hasMode.push(i % mod);
    }
    MyVector<int>y = mode(hasMode);
    std::cout << "\nTesting mode on a vector with modes size: " << hasMode.length()
            << " modding with " << mod;
    printVector(hasMode, mod);
    std::cout << "It has " << y[0] << " modes, highest frequency of " << y[1]
            << " and modes: ";

    for (int i = 2; i < y.length(); i++) {
        std::cout << y[i] << " ";
    }
    std::cout << std::endl;
}

// Problem 3

void MidTerm::problem3() {

    std::cout << "You chose problem 3." << std::endl;

    MyVector<int> vector;

    // to prompt the user for input

    std::cout << "How big a vector do you want? "
            << "Note this will display as a string" << std::endl;
    int size = getInput();
    std::cout << "What do you want to mode by? " << std::endl;
    int mod = getInput();
    for (int i = 0; i < size; i++) {
        vector.push(i % mod);
    }

    std::cout << "Testing StatClass on a vector with size: " <<
            vector.length() << " modding with " << mod << " and elements: ";
    printVector(vector, mod);
    // Create a new StatClass object from this new vector.
    StatClass vectorStat(vector);

    std::cout << "Min: " << vectorStat.getMin() << " Max: "
            << vectorStat.getMax() << " Average: "
            << vectorStat.getAverage() << std::endl;
    std::string mode = vectorStat.getModes();
    std::cout << "Total modes: " << vectorStat.getNumberModes() <<
            " Highest frequency is: " << vectorStat.getFrequency() << std::endl;
    std::cout << "The modes are: " << mode << std::endl;
}

// Problem 4

void MidTerm::problem4() {
    int listSize; // To hold the requested size
    int p; // To hold how many to print out

    std::cout << " You chose problem 4." << std::endl;

    std::cout << std::endl;
    std::cout << "How big a list do you want? ";
    listSize = getInput();
    std::cout << "You chose " << listSize << " as the list size." << std::endl;
    std::cout << "How many top elements would you like? ";
    p = getInput();

    MyList<int> topList;
    MyList<int> myList;


    std::cout << "Size of myList: " << myList.length() << std::endl;
    fillList(myList, listSize);
    std::cout << "Size of myList: " << myList.length() << std::endl;
    printList(myList, 10);
    std::cout << "After sorting list contains: " << std::endl;
    myList.sort();
    printList(myList, 10);
    std::cout << " Size of topList: " << topList.length() << std::endl;
    // Now get the top p elements.
    topList = top(myList, p);
    std::cout << "Size of myList: " << myList.length() << std::endl;
    std::cout << " Size of topList: " << topList.length() << std::endl;
    std::cout << "The top " << p << " elements are: " << std::endl;
    printList(topList, 10);
    std::cout << std::endl;
}

// Problem 5

void MidTerm::problem5() {
    // Declare and fill two vectors. One vector with no mode, one
    // with modes.

    std::cout << "\nYou chose problem 5.";

    std::cout << "How big a list do you want?"
            << "\nNote this will display as a string";

    // Declare and fill the vector with random stuff up to given size
    MyList<int> noMode;
    int size = getInput();
    // Get what the user wants to mode by
    std::cout << "What do you want to mod by? " << std::endl;
    int mod = getInput();
    // Fill the list with numbers where there is no mode to test the
    // mode() function
    for (int i = 0; i < size; i++) {
        noMode.append(i);
    }

    // Output the unsorted array then sort and output again
    std::cout << "\nTesting mode(list) on a vector with no modes "
            << "size: " + noMode.length() << " and has: " << std::endl;
    printList(noMode, mod);
    MyList<int> testMode;
    testMode = mode(noMode);
    std::cout << "\nIt has " << testMode[0] << " modes, highest frequency of " << testMode[1] << std::endl;

    MyList<int> hasMode;

    for (int i = 0; i < size; i++) {
        hasMode.append(i % mod);
    }
    MyList<int>y = mode(hasMode);
    std::cout << "\nTesting mode on a list with modes size: " << hasMode.length()
            << " modding with " << mod;
    printList(hasMode, mod);
    std::cout << "It has " << y[0] << " modes, highest frequency of " << y[1]
            << " and modes: ";

    for (int i = 2; i < y.length(); i++) {
        std::cout << y[i] << " ";
    }
    std::cout << std::endl;
}

// Problem 6

void MidTerm::problem6() {
    std::cout << std::endl;
    std::cout << "You chose problem 6." << std::endl;

    MyList<int> list; // To hold the vectors  



    // to prompt the user for input    
    std::cout << "How big a list do you want? "
            << "Note this will display as a string" << std::endl;
    int size = getInput();
    std::cout << "What do you want to mode by? " << std::endl;
    int mod = getInput();
    for (int i = 0; i < size; i++) {
        list.append(i % mod);
    }

    std::cout << "Testing StatClass on a list with size: " <<
            list.length() << " modding with " << mod << " and elements: ";
    printList(list, mod);

    StatClass listStat(list);

    std::cout << "Min: " << listStat.getMin() << " Max: "
            << listStat.getMax() + " Average: "
            << listStat.getAverage() << std::endl;
    std::string mode = listStat.getModes();
    std::cout << "Total modes: " << listStat.getNumberModes() <<
            " Highest frequency is: " << listStat.getFrequency() << std::endl;
    std::cout << "The modes are: " << mode << std::endl;
    std::cout << std::endl;
}

// Problem 7

void MidTerm::problem7() {
    std::cout << "\nYou chose problem 7.";
    // Ordered lists to fill with random Stuff and Integer
    // SelfOrganizingList<Integer> orderInteger = new
    // SelfOrganizingList<Integer>();
    //OrderedList<Stuff> orderStuff;
    int randomNumber; // For creating stuff

    // to prompt the user for input
    std::cout << "How many items would you like to add to an priority list? "
            << "\nNew items are added to the bottom, "
            << "but will move to top if item is already on the list";
    int size = getInput();

    std::cout << "Enter a number for range of objects of type Stuff (will range from 1 to number)";
    int range = getInput();

    for (int i = 0; i < size; i++) {
        //Stuff stuff(rand()%range+1,"abc");
        //std::cout << "\nAdding: " << stuff.toString() << " to the list. The list before adding: \n";
        //Display list contents before adding the item
       // printList(orderStuff);
        //std::cout << "\n" << stuff << " was in list already? "
          //      << orderStuff.contain(stuff) << "\n\n";
        //Display the list after the addition
        //if (!orderStuff.contain(stuff)) {
        //    orderStuff.insert(stuff);
        //}
        std::cout << "The list after adding:\n ";
        //printList(orderStuff);
    }
}

// Problem 8

void MidTerm::problem8() {
    std::cout << std::endl;
    std::cout << "You selected problem 8: recursive tangent" << std::endl;
    double angle;
    std::cout << "Please enter an angle: ";
    std::cin>>angle;

    std::cout << "You entered: " << angle << std::endl;

    std::cout << "Using recursive tan. The tan of " << angle << " is: " << myTan(angle) << std::endl;
    std::cout << "Using cmath tan. The tan of " << angle << " is: " << std::tan(angle) << std::endl;
    std::cout << std::endl;
}

// Problem 9

void MidTerm::problem9() {
    std::cout << std::endl;
    std::cout << "You chose problem 9: Mutual recursion of g(x) and h(x)";
    std::cout << "h(2x) = h(2x)=2h(x)g(x)";
    std::cout << "g(2x) = 1+2(h(x)^2)";
    // Change in x (delta-x is 0.1)
    std::cout << "Value of x \t\t g(x)\t\t h(x)" << std::endl;
    //Output the values of x, g(x), and h(x) from -1<=x<=1 with delta x = 0.1
    for (double i = -1.0; i <= 1.0; i += .1) {
        std::cout << i << "\t \t" << g(i) << "\t \t" << h(i) << std::endl;
    }
    std::cout << std::endl;
}

int MidTerm::getInput() {
    std::string s; // for user input
    int option = 0; // to check the option
    bool valid = false; // to make user input is valid
    // Prompt user for input
    std::cout << "Enter your option: ";
    std::cin >> option;

    //Keep asking until user enters valid input
    do {
        unsigned int index = 0;
        bool isInt = true;
        char test;
        // Check to make sure the string input is valid
        while (index < s.length() && isInt && s != "") {
            test = s[index];
            if (!std::isdigit(test))
                isInt = false;
            index++;
        }
        // Set the option to user input
        if (isInt) {
            std::stringstream stream(s);
            stream >> option;
            if (option > 0)
                valid = true;
        }
        // If it is not valid ask for valid option
        if (!valid)
            std::cout << "Please enter a valid option." << std::endl;

    } while (!valid);
    return option;
}

// Helper functions for problems 1-6

// Precondition requires that the random number generator be seeded. Should be
// done in main

void MidTerm::fillVector(MyVector<int> &x, int numberOfEntries) {
    // Fill it with random numbers from 10 to 99
    std::cout << "fillVector function" << std::endl;
    for (int i = 0; i < numberOfEntries; i++) {
        x.push((rand() % 90 + 10));
    }
}

// Prints a vector

void MidTerm::printVector(const MyVector<int> &x, int perLine) {
    std::cout << "\nVector contains: " << std::endl;
    for (int i = 0; i < x.length(); i++) {
        std::cout << x[i] << " ";
        if (i % perLine == perLine - 1) {
            std::cout << "\n";
        }
    }
    std::cout << std::endl;
}

MyVector<int> MidTerm::top(const MyVector<int> &x, const int &p)
throw (ExceedSize) {
    // Test to make sure the requested top elements is not bigger than the
    // passed vector size
    if (p < x.length()) {
        MyVector<int> top;
        for (int i = x.length() - 1; i > x.length() - p - 1; i--) {
            top.push(x[i]);
        }
        return top;
    } else {
        throw ExceedSize();
    }

}

MyVector<int> MidTerm::mode(MyVector<int> &x) {
    // Need to sort before getting mode
    x.sort();
    MyVector<int> modeVector;
    int count = 0, frequency = 0, nmodes = 0;
    // Traverse through the vector to find if there are any modes
    for (int i = 1; i < x.length(); i++) {
        if (x[i] == x[i - 1]) {
            count++;
            // We found one entry that may at least be a mode
            if (frequency < count)
                frequency = count;
        } else {
            // reset the count
            count = 0;
        }
    }
    count = 0; // reset the count to find the modes
    for (int i = 1; i < x.length(); i++) {
        // If the frequency matches the count we found a mode
        if (x[i] == x[i - 1]) {
            count++;
            if (frequency == count)
                nmodes++;

        } else {
            // reset the count
            count = 0;
        }
    }
    // Add the frequency and the number of modes to the vector
    modeVector.push(nmodes);
    modeVector.push(frequency + 1);

    count = 0;
    // Now iterate again through the original vector to get the actual modes
    for (int i = 1; i < x.length(); i++) {
        // If the frequency matches the count we found a mode
        if (x[i] == x[i - 1]) {
            count++;
            if (frequency == count)
                modeVector.push(x[i]);
        } else {
            // reset the count
            count = 0;
        }
    }

    return modeVector;
}

// Precondition requires that the random number generator be seeded. Should be
// done in main
void MidTerm::fillList(MyList<int> &x, int numberOfEntries) {
    // Fill it with random numbers from 10 to 99
    std::cout << "fillList function" << std::endl;
    for (int i = 0; i < numberOfEntries; i++) {
        x.append((rand() % 90 + 10));
    }
}

// Prints a list
void MidTerm::printList(const MyList<int> &x, int perLine) {

    std::cout << "\nList contains: " << std::endl;
    for (int i = 0; i < x.length(); i++) {
        std::cout << x[i] << " ";
        if (i % perLine == perLine - 1) {
            std::cout << "\n";
        }
    }
    std::cout << std::endl;
}
// Prints an ordered list
/*
void MidTerm::printList(const OrderedList<Stuff> &x, int perLine) {

    std::cout << "\nList contains: " << std::endl;
    for (int i = 0; i < x.length(); i++) {
        std::cout << x[i].toString() << " ";
        if (i % perLine == perLine - 1) {
            std::cout << "\n";
        }
    }
    std::cout << std::endl;
}
*/
MyList<int> MidTerm::top(const MyList<int> &x, const int &p)
throw (ExceedSize) {
    // Test to make sure the requested top elements is not bigger than the
    // passed list size 
    if (p < x.length()) {
        MyList<int> topList;
        for (int i = x.length() - 1; i > x.length() - p - 1; i--) {
            topList.append(x[i]);
        }
        return topList;
    } else {
        throw ExceedSize();
    }
}

MyList<int> MidTerm::mode(MyList<int> &x) {
    // Need to sort before getting mode
    x.sort();
    MyList<int> modeList;
    int count = 0, frequency = 0, nmodes = 0;
    // Traverse through the vector to find if there are any modes
    for (int i = 1; i < x.length(); i++) {
        if (x[i] == x[i - 1]) {
            count++;
            // We found one entry that may at least be a mode
            if (frequency < count)
                frequency = count;
        } else {
            // reset the count
            count = 0;
        }
    }
    count = 0; // reset the count to find the modes
    for (int i = 1; i < x.length(); i++) {
        // If the frequency matches the count we found a mode
        if (x[i] == x[i - 1]) {
            count++;
            if (frequency == count)
                nmodes++;

        } else {
            // reset the count
            count = 0;
        }
    }
    // Add the frequency and the number of modes to the vector
    modeList.append(nmodes);
    modeList.append(frequency + 1);

    count = 0;
    // Now iterate again through the original list to get the actual modes
    for (int i = 1; i < x.length(); i++) {
        // If the frequency matches the count we found a mode
        if (x[i] == x[i - 1]) {
            count++;
            if (frequency == count)
                modeList.append(x[i]);
        } else {
            // reset the count
            count = 0;
        }
    }

    return modeList;
}

// Returns the tan of an angle.

double MidTerm::myTan(double x) {
    double x2 = (x / 2);
    double epsilon = 1e-2;
    if (x2>-epsilon && x2 < epsilon) {
        return (x + (x * x * x / 3));
    }
    double tanv = myTan(x2);
    double y = 2 * tanv / (1 - tanv * tanv);
    return (y);
}

// Recursively calculate g

double MidTerm::g(double x) {
    double x2 = (x / 2);
    double epsilon = 1e-6;
    if (x2>-epsilon && x2 < epsilon) {
        return (1 + (x * x / 2));
    }
    //double g1=g(x2);
    double h1 = h(x2);
    return (1 + 2 * h1 * h1);
}

// Recursively calculate h

double MidTerm::h(double x) {
    double x2 = (x / 2);
    double epsilon = 1e-6;
    if (x2>-epsilon && x2 < epsilon) {
        return (x + (x * x * x / 6));
    }
    double g1 = g(x2);
    double h1 = h(x2);
    return (2 * h1 * g1);
}

//*******************************************************
// memError function. Displays an error message and     *
// terminates the program when memory allocation fails. *
//*******************************************************

void MidTerm::memError() const {
    std::cout << "ERROR:Cannot allocate memory.\n";
    exit(EXIT_FAILURE);
}


