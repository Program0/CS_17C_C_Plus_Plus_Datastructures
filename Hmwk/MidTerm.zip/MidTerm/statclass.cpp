

#include "statclass.h"

StatClass::StatClass(MyVector<int> x){
    // Set the min and max since we can sort MyVector x
    x.sort();
    min = x[0];
    max = (x[x.length() - 1]);
    numberModes = 0;
    frequency = 0; // For holding the max frequency                
    int sum = 0; // To determine the average

    // Go through the vector adding unique elements to the map
    // and updating each element's frequency.
    std::map<int, int> freq;    
    
    for (int i = 0; i < x.length(); i++) {       
        // If an element is not there add with freq. 1
        if (!freq.count(x[i])) {
            freq[x[i]] = 1;
        } else {
            int count = freq.at(x[i]) + 1;
            if (frequency < count)
                frequency = count;
            freq.at(x[i]) = count;
        }
        sum += x[i];
    }
    // Now go through each element in the map and compare its frequency 
    // with the highest frequency found. This will give us the modes.

    average = sum / static_cast<float>(x.length());
    int mode = 0;
    
    std::stringstream s;
    
    typedef std::map<int, int>::iterator map_it;
    for (map_it iterator = freq.begin(); iterator != freq.end(); iterator++) {
        // Insert the frequency values into the set                
        if (frequency == iterator->second) {
            numberModes++;
            mode = iterator->first;
            s<< mode <<" ";
        }
    }
    
    modes = s.str();
}

StatClass::StatClass(MyList<int>& x) {
    // Set the min and max since we can sort MyList x
    x.sort();
    min = x[0];
    max = (x[x.length() - 1]);
    numberModes = 0;
    frequency = 1; // For holding the max frequency                
    int sum = 0; // To determine the average

    // Go through the vector adding unique elements to the map
    // and updating each element's frequency.
    std::map<int, int> freq;    
    
    for (int i = 0; i < x.length(); i++) {       
        // If an element is not there add with freq. 1
        if (!freq.count(x[i])) {
            freq[x[i]] = 1;
        } else {
            int count = freq.at(x[i]) + 1;
            if (frequency < count)
                frequency = count;
            freq.at(x[i]) = count;
        }
        sum += x[i];
    }
    // Now go through each element in the map and compare its frequency 
    // with the highest frequency found. This will give us the modes.

    average = sum / x.length();
    int mode = 0;
    
    std::stringstream s;
    
    typedef std::map<int, int>::iterator map_it;
    for (map_it iterator = freq.begin(); iterator != freq.end(); iterator++) {
        // Insert the frequency values into the set                
        if (frequency == iterator->second) {
            numberModes++;
            mode = iterator->first;
            s<<mode << " ";
        }
    }
    
    modes = s.str();
}




