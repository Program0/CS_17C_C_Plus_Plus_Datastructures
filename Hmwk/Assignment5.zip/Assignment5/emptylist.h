#ifndef EMPTYLIST_H
#define EMPTYLIST_H

class EmptyList{
    // Intentionally left empty
};

#endif // EMPTYLIST_H

