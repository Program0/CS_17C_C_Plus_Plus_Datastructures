#ifndef EMPTYVECTOR
#define EMPTYVECTOR

class EmptyVector{

};

#endif // EMPTYVECTOR

